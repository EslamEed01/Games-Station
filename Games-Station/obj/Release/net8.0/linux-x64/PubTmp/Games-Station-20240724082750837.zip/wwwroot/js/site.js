﻿$(document).ready(function () {
    $('select').select2()
});

$('select:not(.select2-no-search)').select2();